AC2 - Aplicação Angular de inscrições em oficinas

COMO EXECUTAR
1. Instale Node.js compatível com Angular 21.
2. Extraia esta pasta.
3. Abra o terminal dentro da pasta ac2-faculdade.
4. Execute: npm install
5. Execute: npm start
6. O navegador abrirá a aplicação; se não abrir, acesse http://localhost:4200

COMO TESTAR
- Cadastre nome, e-mail e uma das três oficinas.
- Clique em "Ver inscrições".
- Confirme uma inscrição: o status muda para Confirmada e o botão fica desabilitado.
- Remova uma inscrição.
- Confira os contadores e a mensagem quando a lista estiver vazia.

IMPORTANTE SOBRE O ENUNCIADO
O PDF contém uma contradição: uma instrução inicial menciona substituir a lógica de tarefas por cadastro de frutas, mas a especificação detalhada descreve inscrições em oficinas. Este código implementa a especificação detalhada de inscrições em oficinas. Confirme com o professor qual interpretação ele espera.

Os nomes de variáveis usados no código incluem nomes de Pokémon conforme solicitado. A interface Inscricao e os métodos listar/adicionar/remover/confirmarInscricao seguem a descrição detalhada.
Os dados ficam apenas em memória e podem desaparecer ao atualizar ou fechar a aplicação.
