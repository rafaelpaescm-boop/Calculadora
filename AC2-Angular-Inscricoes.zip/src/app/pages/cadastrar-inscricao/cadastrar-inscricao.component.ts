import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { InscricaoService } from '../../services/inscricao.service';

@Component({
  selector: 'app-cadastrar-inscricao',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <section class="card">
      <p class="eyebrow">NOVA INSCRIÇÃO</p>
      <h1>Cadastrar participante</h1>
      <p class="muted">Preencha os dados para inscrever alguém em uma oficina.</p>

      @if (mensagem) {
        <div class="notice" [class.success]="sucesso" [class.error]="!sucesso" role="status">
          {{ mensagem }}
        </div>
      }

      <form (ngSubmit)="cadastrar()">
        <div class="field">
          <label for="nome">Nome completo</label>
          <input id="nome" name="nome" [(ngModel)]="nome" required maxlength="100"
                 placeholder="Ex.: Ana da Silva">
        </div>
        <div class="field">
          <label for="email">E-mail</label>
          <input id="email" name="email" type="email" [(ngModel)]="email" required
                 placeholder="ana@email.com">
        </div>
        <div class="field">
          <label for="oficina">Oficina</label>
          <select id="oficina" name="oficina" [(ngModel)]="oficina" required>
            <option value="" disabled>Selecione uma oficina</option>
            <option value="Programação">Programação</option>
            <option value="Fotografia">Fotografia</option>
            <option value="Empreendedorismo">Empreendedorismo</option>
          </select>
        </div>
        <div class="actions">
          <button class="btn btn-primary" type="submit">Cadastrar inscrição</button>
          <a class="btn btn-link" routerLink="/lista">Ver inscrições</a>
        </div>
      </form>
    </section>
  `,
  styles: [`
    .eyebrow { color:#6941c6; font-weight:800; font-size:12px; letter-spacing:1.5px; }
    form { margin-top:24px; max-width:620px; }
  `]
})
export class CadastrarInscricaoComponent {
  nome = '';
  email = '';
  oficina = '';
  mensagem = '';
  sucesso = false;

  constructor(private charizard: InscricaoService) {}

  cadastrar(): void {
    const nomeLimpo = this.nome.trim();
    const emailLimpo = this.email.trim();

    if (!nomeLimpo || !emailLimpo || !this.oficina) {
      this.mensagem = 'Preencha todos os campos.';
      this.sucesso = false;
      return;
    }

    this.charizard.adicionar({
      nome: nomeLimpo,
      email: emailLimpo,
      oficina: this.oficina
    });

    this.mensagem = 'Inscrição cadastrada com status Pendente!';
    this.sucesso = true;
    this.nome = '';
    this.email = '';
    this.oficina = '';
  }
}