import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Inscricao, InscricaoService } from '../../services/inscricao.service';

@Component({
  selector: 'app-lista-inscricoes',
  standalone: true,
  imports: [RouterLink],
  template: `
    <section class="heading">
      <div>
        <p class="eyebrow">GERENCIAMENTO</p>
        <h1>Inscrições cadastradas</h1>
        <p class="muted">Confira, confirme ou remova inscrições.</p>
      </div>
      <a class="btn btn-primary" routerLink="/cadastro">+ Nova inscrição</a>
    </section>

    <section class="stats" aria-label="Contadores">
      <article class="stat"><span>Total</span><strong>{{ inscricoes.length }}</strong></article>
      <article class="stat"><span>Confirmadas</span><strong>{{ totalConfirmadas }}</strong></article>
      <article class="stat"><span>Pendentes</span><strong>{{ totalPendentes }}</strong></article>
    </section>

    @if (inscricoes.length === 0) {
      <div class="card empty">
        <h2>Nenhuma inscrição cadastrada</h2>
        <p class="muted">Cadastre a primeira inscrição para ela aparecer aqui.</p>
        <a class="btn btn-primary" routerLink="/cadastro">Ir para cadastro</a>
      </div>
    } @else {
      <div class="registration-list">
        @for (item of inscricoes; track item.id) {
          <article class="card registration">
            <div class="person">
              <h2>{{ item.nome }}</h2>
              <p>{{ item.email }}</p>
              <p><strong>Oficina:</strong> {{ item.oficina }}</p>
              <span class="status" [class.pending]="item.status === 'Pendente'"
                    [class.confirmed]="item.status === 'Confirmada'">
                {{ item.status }}
              </span>
            </div>
            <div class="actions">
              <button class="btn btn-primary" type="button"
                      [disabled]="item.status === 'Confirmada'"
                      (click)="confirmar(item.id)">
                {{ item.status === 'Confirmada' ? 'Inscrição confirmada' : 'Confirmar inscrição' }}
              </button>
              <button class="btn btn-remove" type="button" (click)="remover(item.id)">Remover</button>
            </div>
          </article>
        }
      </div>
    }
    <div class="actions bottom-link">
      <a class="btn btn-link" routerLink="/cadastro">Voltar ao cadastro</a>
    </div>
  `,
  styles: [`
    .heading { display:flex; justify-content:space-between; align-items:center; gap:16px; margin-bottom:24px; }
    .eyebrow { color:#6941c6; font-weight:800; font-size:12px; letter-spacing:1.5px; }
    .stats { display:grid; grid-template-columns:repeat(3,1fr); gap:14px; margin-bottom:22px; }
    .stat { background:white; padding:18px; border-radius:13px; box-shadow:0 5px 18px #181c410d; display:grid; gap:8px; }
    .stat span { color:#686b80; font-size:14px; }
    .stat strong { font-size:28px; }
    .registration-list { display:grid; gap:14px; }
    .registration { display:flex; align-items:center; justify-content:space-between; gap:18px; }
    .person h2 { margin-bottom:8px; font-size:19px; }
    .person p { margin:6px 0; color:#686b80; overflow-wrap:anywhere; }
    .status { display:inline-block; margin-top:8px; padding:6px 10px; border-radius:999px; font-size:12px; font-weight:800; }
    .pending { background:#fef3c7; color:#92400e; }
    .confirmed { background:#fee2e2; color:#991b1b; }
    .empty { text-align:center; padding:36px 20px; }
    .bottom-link { margin-top:20px; }
    @media(max-width:650px) {
      .heading, .registration { align-items:stretch; flex-direction:column; }
      .stats { grid-template-columns:1fr; }
      .registration .actions .btn { flex:1; }
    }
  `]
})
export class ListaInscricoesComponent {
  inscricoes: Inscricao[] = [];

  constructor(private blastoise: InscricaoService) {
    this.atualizarLista();
  }

  get totalConfirmadas(): number {
    return this.inscricoes.filter((articuno) => articuno.status === 'Confirmada').length;
  }

  get totalPendentes(): number {
    return this.inscricoes.filter((zapdos) => zapdos.status === 'Pendente').length;
  }

  confirmar(id: number): void {
    this.blastoise.confirmarInscricao(id);
    this.atualizarLista();
  }

  remover(id: number): void {
    this.blastoise.remover(id);
    this.atualizarLista();
  }

  private atualizarLista(): void {
    this.inscricoes = [...this.blastoise.listar()];
  }
}