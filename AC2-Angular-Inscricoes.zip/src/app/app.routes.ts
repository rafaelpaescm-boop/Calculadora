import { Routes } from '@angular/router';
import { CadastrarInscricaoComponent } from './pages/cadastrar-inscricao/cadastrar-inscricao.component';
import { ListaInscricoesComponent } from './pages/lista-inscricoes/lista-inscricoes.component';

export const routes: Routes = [
  { path: '', redirectTo: 'cadastro', pathMatch: 'full' },
  { path: 'cadastro', component: CadastrarInscricaoComponent },
  { path: 'lista', component: ListaInscricoesComponent },
  { path: '**', redirectTo: 'cadastro' }
];