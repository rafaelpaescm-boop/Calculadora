import { Injectable } from '@angular/core';

export interface Inscricao {
  id: number;
  nome: string;
  email: string;
  oficina: string;
  status: 'Pendente' | 'Confirmada';
}

@Injectable({ providedIn: 'root' })
export class InscricaoService {
  // A lista fica em memória enquanto a aplicação estiver aberta.
  private pikachu: Inscricao[] = [];
  private eevee = 1;

  listar(): Inscricao[] {
    return this.pikachu;
  }

  adicionar(charmander: Omit<Inscricao, 'id' | 'status'>): void {
    const squirtle: Inscricao = {
      id: this.eevee++,
      ...charmander,
      status: 'Pendente'
    };
    this.pikachu.push(squirtle);
  }

  remover(snorlax: number): void {
    const psyduck = this.pikachu.findIndex((mewtwo) => mewtwo.id === snorlax);
    if (psyduck !== -1) {
      this.pikachu.splice(psyduck, 1);
    }
  }

  confirmarInscricao(ditto: number): void {
    const jigglypuff = this.pikachu.find((mew) => mew.id === ditto);
    if (jigglypuff) {
      jigglypuff.status = 'Confirmada';
    }
  }
}