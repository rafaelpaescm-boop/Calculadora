import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterLink, RouterOutlet],
  template: `
    <header class="topbar">
      <div class="container topbar-inner">
        <a class="brand" routerLink="/cadastro">AC2 · Oficinas</a>
        <span>Gestão de inscrições</span>
      </div>
    </header>
    <main class="container main-content">
      <router-outlet></router-outlet>
    </main>
    <footer class="footer">Projeto acadêmico Angular · Dados mantidos em memória</footer>
  `,
  styles: [`
    .topbar { background:#282044; color:white; padding:18px 0; }
    .topbar-inner { display:flex; align-items:center; justify-content:space-between; gap:16px; }
    .brand { color:white; text-decoration:none; font-size:20px; font-weight:800; }
    .main-content { padding-top:32px; padding-bottom:36px; min-height:80vh; }
    .footer { text-align:center; color:#77798c; padding:20px; font-size:13px; }
    @media(max-width:520px) { .topbar-inner { align-items:flex-start; flex-direction:column; } }
  `]
})
export class AppComponent {}